package cn.jbolt.common.config;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import org.json.JSONObject;

import com.jfinal.core.Controller;

public class login extends Controller {
	public void index() {
		String getRequest = getRawData();
		renderText(getRequest);
		System.out.println(getRequest);

		// 判断方法是不是get请求
		if (getRequest().getMethod() == "GET") {

			JSONObject jsonParam = new JSONObject();
			jsonParam.put("command", "ack_signature");
			long seconds = ChronoUnit.SECONDS.between(LocalDateTime.of(1970, 1, 1, 0, 0, 0), LocalDateTime.now());
			jsonParam.put("timestamp", (int) seconds);
			//System.out.println(jsonParam.toString());// 输出下自己输入的json数据
			renderJson(jsonParam.toString());// 提交json数据给客户端

		} else  {
			{
				JSONObject jsonParam1 = new JSONObject();
				jsonParam1.put("command", "reply_login");
				jsonParam1.put("token", "1234woaini");
				jsonParam1.put("errcode", 0);
				jsonParam1.put("errmsg", "ok");
				//System.out.println(jsonParam1.toString());// 输出下自己输入的json数据
				renderJson(jsonParam1.toString());// 提交json数据给客户端
			}
			

		}

	}
}
