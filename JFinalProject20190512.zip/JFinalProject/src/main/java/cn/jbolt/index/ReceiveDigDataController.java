package cn.jbolt.index;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.jetty.client.HttpRequest;
import org.eclipse.jetty.client.HttpResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONWriter;

import com.jfinal.core.Controller;
import com.jfinal.json.JFinalJson;
import com.sun.tools.javac.util.List;



public class ReceiveDigDataController extends Controller {
	

	public void index() throws ServletException, IOException {
		String result = getRawData();
		System.out.println(result);
		//set("result", result);
		/*JSONObject jsonObject = new JSONObject(result);
		dataJsonShow dataJsonShow = new dataJsonShow();
		dataJsonShow.setCommand(jsonObject.getString("command"));
		ArrayList<data> datas = new ArrayList<>();
		dataJsonShow.setDatas(datas);
		JSONArray jsonArray2=jsonObject.getJSONArray("data");
		System.out.println(jsonArray2);*/
		
		
		
		
		//render("ResultRequest.jsp");
		
		 
	
	
		
		
		
		
	}

}
