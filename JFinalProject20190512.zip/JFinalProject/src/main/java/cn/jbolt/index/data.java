package cn.jbolt.index;

import com.alibaba.druid.stat.TableStat.Name;

public class data {
	private String name ,shot ,identity,address ,time;
	public data() {
		super();
	}
	public data(String name ,String shot ,String identity, String address , String time) {
		super();
		this.name = name;
		this.time = time;
		this.address = address ;
		this.identity = identity ;
		this.shot = shot ;
	}
	@Override
    public String toString() {
        return "data [identity=" + identity + ", name=" + name + ", shot=" + shot + "]";
    }
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getShot() {
		return shot;
	}

	public void setShot(String shot) {
		this.shot = shot;
	}

	public String getIdentity() {
		return identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

}
