package cn.jbolt.index;

import com.jfinal.core.Controller;

public class uploadInterface extends Controller {
	
	public void index() {
		
		String result = getRawData();
		//set("result", result);
		renderText(result);
		System.out.println(result);
		
	} 
}
