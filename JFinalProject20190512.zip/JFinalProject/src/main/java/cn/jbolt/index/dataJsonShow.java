package cn.jbolt.index;

import java.util.ArrayList;

import sun.tools.tree.SuperExpression;

public class dataJsonShow {
	private String command;
	

	private ArrayList<data> datas;
	private String datatype ;
	private String msgid;
	public dataJsonShow(String command,ArrayList<data> datas, String datatype ,String msgid) {
		super();
		this.command = command;
		this.datas = datas;
		this.datatype = datatype;
		this.msgid = msgid;
	}
	public dataJsonShow() {
		super();		// TODO Auto-generated constructor stub
	}
		
	
	public String getCommand() {
		return command;
	}
	public void setCommand(String command) {
		this.command = command;
	}
	public ArrayList<data> getDatas() {
		return datas;
	}
	public void setDatas(ArrayList<data> datas) {
		this.datas = datas;
	}
	public String getDatatype() {
		return datatype;
	}
	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}
	public String getMsgid() {
		return msgid;
	}
	public void setMsgid(String msgid) {
		this.msgid = msgid;
	}
}
